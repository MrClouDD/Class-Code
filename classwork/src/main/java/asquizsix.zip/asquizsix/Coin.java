package asquizsix;

public class Coin {
    private String name;
    Coin(String n) {
        name = n;
    }
    public String getCoinName() {
        return name;
    }
}
